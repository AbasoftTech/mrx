@extends('layouts.master')
@section('content')
 <h1>about</h1>
@endsection
